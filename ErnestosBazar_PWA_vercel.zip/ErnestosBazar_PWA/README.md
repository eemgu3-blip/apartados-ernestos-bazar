
# Ernesto’s Bazar Apartados - PWA (Vercel-ready)

Archivos en este paquete:
- index.html
- styles.css
- app.js
- manifest.json
- sw.js
- icons/icon.svg

## Despliegue en Vercel (rápido)
1. Crea una cuenta en Vercel e inicia sesión.
2. Crea un nuevo repo en GitHub (por ejemplo `apartados-ernestos-bazar`).
3. Sube todos los archivos de este paquete a la raíz del repo (puedes arrastrar y soltar en la web de GitHub).
4. En Vercel: "Import Project" → selecciona el repo → Deploy.
5. Después de unos segundos tendrás la URL pública (ej. https://apartados-ernestos-bazar.vercel.app).

## Uso en iPad
1. Abre la URL en Safari.
2. Compartir → Agregar a pantalla de inicio.
3. Abre desde el icono y úsala offline.

## Envío de tickets
- PDF: el botón "Ticket" descarga un PDF (o texto si el navegador no soporta jsPDF).
- SMS: abre la app Mensajes con el texto prellenado (el usuario debe enviar).
- WhatsApp: abre WhatsApp / web.whatsapp con el mensaje listo.

Si quieres, puedo subir el repo por ti a GitHub y conectar Vercel directamente (necesitaría autorización OAuth con GitHub; si no quieres dar acceso, te guío paso a paso).
